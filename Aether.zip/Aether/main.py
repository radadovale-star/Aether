
import os
import pandas as pd
import LIBs.at as git
import LIBs.pudimLIB as c
from LIBs.pudimLIB import seta, barra
import urllib.request


def baixar(url, destino):
    requisicao = urllib.request.Request(
        url,
        headers={"User-Agent": "Mozilla/5.0"}
    )

    with urllib.request.urlopen(requisicao, timeout=5) as resposta:
        with open(destino, "wb") as f:
            f.write(resposta.read())


url = "https://raw.githubusercontent.com/radadovale-star/Aether/main/Fichas.txt"

baixar(url, "Fichas.txt")

with open("Fichas.txt", "r", encoding="utf-8") as arquivo:
    fichas = arquivo.read()

ARQUIVO = "Fichas.txt"
COLUNAS = ["Nome/", "Idade/", "Altura/", "Peso/", "Classe/"]


def titulo():
    c.limpar()
    print("=" * 45)
    print("          SISTEMA DE FICHAS //AUTO//")
    print("=" * 45)


def carregar_fichas():
    baixar(url, "Fichas.txt")
    if not os.path.exists(ARQUIVO):
        return pd.DataFrame(columns=COLUNAS)

    try:
        return pd.read_csv(ARQUIVO, sep=r"\s{2,}", engine="python")
    except (pd.errors.EmptyDataError, pd.errors.ParserError):
        return pd.DataFrame(columns=COLUNAS)


def importar_ficha():
    titulo()
    print("           IMPORTAÇÃO DE FICHAS")
    print(barra)

    try:
        nome = input("Nome: ")
        idade = int(input("Idade: "))
        altura = float(input("Altura: "))
        peso = float(input("Peso: "))
        classe = input("Classe: ")

        nova_ficha = pd.DataFrame([{
            "Nome/": nome,
            "Idade/": idade,
            "Altura/": altura,
            "Peso/": peso,
            "Classe/": classe
        }])

        # Salvar com espaçamento
        if os.path.exists(ARQUIVO) and os.path.getsize(ARQUIVO) > 0:
            with open(ARQUIVO, "a", encoding="utf-8") as arquivo:
                arquivo.write("\n\n")
                arquivo.write(nova_ficha.to_string(index=False))
        else:
            with open(ARQUIVO, "w", encoding="utf-8") as arquivo:
                arquivo.write(nova_ficha.to_string(index=False))

        print("\nFicha adicionada com sucesso!")

        git.inv(ARQUIVO)

    except ValueError:
        print("\nErro: digite valores numéricos válidos!")

    input("\nPressione ENTER para continuar...")


def visualizar_fichas():
    titulo()
    print("           FICHAS REGISTRADAS")
    print(barra)

    if not os.path.exists(ARQUIVO):
        print("Nenhuma ficha encontrada.")
    else:
        with open(ARQUIVO, "r", encoding="utf-8") as arquivo:
            print(arquivo.read())

    input("\nPressione ENTER para continuar...")


def menu():
    while True:
        titulo()

        print("[1] Importar fichas")
        print("[2] Visualizar fichas")
        print("[3] Sair")
        print(barra)

        escolha = input(seta)

        if escolha == "1":
            importar_ficha()

        elif escolha == "2":
            visualizar_fichas()

        elif escolha == "3":
            print("\nEncerrando o sistema...")
            c.tempo(2)
            break

        else:
            print("\nOpção inválida!")
            c.tempo(1)


if __name__ == "__main__":
    print("Inicializando Fichas //AUTO//...")
    c.tempo(2)
    menu()

