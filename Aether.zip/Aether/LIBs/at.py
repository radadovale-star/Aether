
import requests
import base64
from pathlib import Path

def inv(ARQUIVO):

    # Configurações
    TOKEN = "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"
    USUARIO = "radadovale-star"
    REPO = "Aether"

    arquivo = Path(ARQUIVO)

    if not arquivo.is_file():
        print("[ERRO] Arquivo não encontrado!")
        return False

    nome = arquivo.name

    url = f"https://api.github.com/repos/{USUARIO}/{REPO}/contents/{nome}"

    headers = {
        "Authorization": f"Bearer {TOKEN}",
        "Accept": "application/vnd.github+json"
    }

    try:
        # Codifica o arquivo
        with open(arquivo, "rb") as f:
            conteudo = base64.b64encode(f.read()).decode("utf-8")

        # Verifica se já existe
        consulta = requests.get(
            url,
            headers=headers,
            timeout=30
        )

        if consulta.status_code == 200:
            sha = consulta.json()["sha"]

        elif consulta.status_code == 404:
            sha = None

        else:
            print("[ERRO]", consulta.status_code, consulta.text)
            return False

        # Dados do upload
        dados = {
            "message": f"Upload de {nome}",
            "content": conteudo
        }

        if sha:
            dados["sha"] = sha

        # Envia para o GitHub
        resposta = requests.put(
            url,
            headers=headers,
            json=dados,
            timeout=60
        )

        if resposta.status_code in (200, 201):
            print(f"[SUCESSO] {nome} enviado!")
            return True

        print("[ERRO]", resposta.status_code, resposta.text)
        return False

    except requests.RequestException as erro:
        print("[ERRO] Conexão:", erro)
        return False

    except OSError as erro:
        print("[ERRO] Arquivo:", erro)
        return False
